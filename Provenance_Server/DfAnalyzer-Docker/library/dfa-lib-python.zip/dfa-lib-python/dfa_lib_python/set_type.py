from enum import Enum


class SetType(Enum):
    """ This class is a enum with all the possibles dataset types.
    """
    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'
